package com.travelgo.users.model;
public class Entity {}