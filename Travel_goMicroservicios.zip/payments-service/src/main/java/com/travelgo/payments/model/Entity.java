package com.travelgo.payments.model;
public class Entity {}