package com.travelgo.bookings.model;
public class Entity {}